package actividad1;

import java.util.Random;

public class Docente extends Persona {
    String cursoDocente;
    String facultadDocente;

    public Docente(String dni, String nombre, String apellido, String cursoDocente, String facultadDocente) {
        super(dni, nombre, apellido);
        this.cursoDocente = cursoDocente;
        this.facultadDocente = facultadDocente;
    }

    public void calificarCurso(Curso curso) {
        Random rand = new Random();
        int nota = rand.nextInt(21); // Genera una nota entre 0 y 20
        System.out.println("Curso: " + curso.nombreCurso + " Nota: " + nota);
    }

}
