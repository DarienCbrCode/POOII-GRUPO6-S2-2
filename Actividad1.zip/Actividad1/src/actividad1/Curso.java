package actividad1;

public class Curso {
    String nombreCurso;

    public Curso(String nombreCurso) {
        this.nombreCurso = nombreCurso;
    }

    @Override
    public String toString() {
        return nombreCurso;
    }

}

