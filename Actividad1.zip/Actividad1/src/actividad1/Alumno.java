package actividad1;

import java.util.List;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Alumno extends Persona {
    private String codigoAlumno;
    private List<Curso> listaCursos;

    public Alumno(String codigo, String nombre, String apellido, List<Curso> listaCursos) {
        super(codigo, nombre, apellido); 
        this.codigoAlumno = codigo;
        this.listaCursos = listaCursos != null ? listaCursos : new ArrayList<>();
        this.leeCursosAlumno("CursosDisponibles.txt");
    }

    public List<Curso> getCursos() {
        return listaCursos;
    }

    public void setCursos(List<Curso> listaCursos) {
        this.listaCursos = listaCursos;
    }

    public void leeCursosAlumno(String archivo) {
    File file = new File(archivo);
    System.out.println("Ruta absoluta del archivo: " + file.getAbsolutePath());
    if (!file.exists()) {
        System.out.println("El archivo no existe.");
        return;
    }
    
    try (BufferedReader br = new BufferedReader(new FileReader(file))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            listaCursos.add(new Curso(linea));
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
}
