package actividad1;

public class Persona {
    String dni;
    String nombre;
    String apellido;

    public Persona(String dni, String nombre, String apellido) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
    }

}
